<?php

namespace App\Helpers;

use App\Models\Warehouse;

class CommonLocationFilter
{
    public static function resolveWarehouseIds(array $filter): array
    {
        // Priority: route > warehouse > area > region > company

        if (!empty($filter['route'])) {
            return Warehouse::whereIn('id', self::ids($filter['route']))
                ->pluck('id')
                ->toArray();
        }

        if (!empty($filter['warehouse'])) {
            return self::ids($filter['warehouse']);
        }

        if (!empty($filter['area'])) {
            return Warehouse::whereIn('area_id', self::ids($filter['area']))
                ->pluck('id')
                ->toArray();
        }

        if (!empty($filter['region'])) {
            return Warehouse::whereHas('area', function ($q) use ($filter) {
                $q->whereIn('region_id', self::ids($filter['region']));
            })->pluck('id')->toArray();
        }

        if (!empty($filter['company'])) {
            return Warehouse::whereHas('area.region', function ($q) use ($filter) {
                $q->whereIn('company_id', self::ids($filter['company']));
            })->pluck('id')->toArray();
        }

        return [];
    }

    /**
     * Normalize IDs:
     * - array: [1,2]
     * - string: "1,2"
     * - string: "1"
     */
    private static function ids($value): array
    {
        if (empty($value)) {
            return [];
        }

        // If already array → clean & return
        if (is_array($value)) {
            return array_values(
                array_filter(
                    array_map('intval', $value)
                )
            );
        }

        // If comma-separated string
        return array_values(
            array_filter(
                array_map('intval', explode(',', (string) $value))
            )
        );
    }
}
