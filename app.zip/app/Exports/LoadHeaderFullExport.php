<?php

namespace App\Exports;

use App\Models\Agent_Transaction\LoadHeader;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use Carbon\Carbon;

class LoadHeaderFullExport implements
    FromCollection,
    WithHeadings,
    ShouldAutoSize,
    WithEvents
{
    public function collection()
    {
        $rows = [];

        $loads = LoadHeader::with([
            'warehouse',
            'route',
            'salesman',
            'salesmantype',
            'projecttype'
        ])->get();

        foreach ($loads as $load) {

            $rows[] = [
                'Load No' => (string) $load->osa_code,
                'Load Date' => optional($load->created_at)->format('d-m-Y'),
                'Accept Date' => $load->accept_time
                                ? Carbon::parse($load->accept_time)->format('d-m-Y')
                                : '',
                'Warehouse' => trim(
                    ($load->warehouse->warehouse_code ?? '') . ' - ' .
                    ($load->warehouse->warehouse_name ?? '')
                ),

                'Route' => trim(
                    ($load->route->route_code ?? '') . ' - ' .
                    ($load->route->route_name ?? '')
                ),

                'Salesman' => trim(
                    ($load->salesman->osa_code ?? '') . ' - ' .
                    ($load->salesman->name ?? '')
                ),

                'Salesman Type' => (string) ($load->salesmantype->salesman_type_name ?? ''),
                'Project Type'  => (string) ($load->projecttype->name ?? ''),

                'Status' => $load->is_confirmed == 1 ? 'SalesTeam Accepted' : 'Waiting For Accept',
            ];
        }

        return new Collection($rows);
    }

    public function headings(): array
    {
        return [
            'Load No',
            'Load Date',
            'Accept Date',
            'Warehouse',
            'Route',
            'Salesman',
            'Salesman Type',
            'Project Type',
            'Status',
        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {

                $sheet = $event->sheet->getDelegate();
                $lastColumn = $sheet->getHighestColumn();

                $sheet->getStyle("A1:{$lastColumn}1")->applyFromArray([
                    'font' => [
                        'bold'  => true,
                        'color' => ['rgb' => 'F5F5F5'],
                    ],
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER,
                        'vertical'   => Alignment::VERTICAL_CENTER,
                    ],
                    'fill' => [
                        'fillType'   => Fill::FILL_SOLID,
                        'startColor' => ['rgb' => '993442'],
                    ],
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color'       => ['rgb' => '000000'],
                        ],
                    ],
                ]);

                $sheet->getRowDimension(1)->setRowHeight(25);
            },
        ];
    }
}
