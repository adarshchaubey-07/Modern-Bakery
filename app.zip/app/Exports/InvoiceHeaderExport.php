<?php

namespace App\Exports;

use App\Models\Agent_Transaction\InvoiceHeader;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use Maatwebsite\Excel\Concerns\Exportable;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;

class InvoiceHeaderExport implements FromQuery, WithMapping, WithHeadings, WithEvents
{
    use Exportable;

    protected $fromDate;
    protected $toDate;

    public function __construct($fromDate = null, $toDate = null)
    {
        $this->fromDate = $fromDate;
        $this->toDate   = $toDate;
    }

    public function query()
    {
        $query = InvoiceHeader::with([
            'order',
            'delivery',
            'warehouse',
            'route',
            'customer',
            'salesman',
        ]);

        if ($this->fromDate) {
            $query->whereDate('invoice_date', '>=', $this->fromDate);
        }

        if ($this->toDate) {
            $query->whereDate('invoice_date', '<=', $this->toDate);
        }

        return $query;
    }

    public function map($header): array
    {
        return [
            $header->invoice_code,
            $header->currency_name,
            $header->order->order_code ?? '',
            $header->delivery->delivery_code ?? '',
            trim(
                ($header->warehouse->warehouse_code ?? '') . ' - ' .
                ($header->warehouse->warehouse_name ?? '')
            ),

            trim(
                ($header->route->route_code ?? '') . ' - ' .
                ($header->route->route_name ?? '')
            ),

            trim(
                ($header->customer->osa_code ?? '') . ' - ' .
                ($header->customer->name ?? '')
            ),

            trim(
                ($header->salesman->osa_code ?? '') . ' - ' .
                ($header->salesman->name ?? '')
            ),

            $header->invoice_date,
            $header->invoice_time,
            (float) $header->vat,
            (float) $header->net_total,
            (float) $header->gross_total,
            (float) $header->discount,
            (float) $header->total_amount,
            $header->status == 1 ? 'Active' : 'Inactive',
        ];
    }

    public function headings(): array
    {
        return [
            'Invoice Code',
            'Currency Name',
            'Order Code',
            'Delivery Code',
            'Warehouse',
            'Route',
            'Customer',
            'Salesman',
            'Invoice Date',
            'Invoice Time',
            'VAT',
            'Net Total',
            'Gross Total',
            'Discount',
            'Total Amount',
            'Status',
        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {

                $sheet = $event->sheet->getDelegate();
                $lastColumn = $sheet->getHighestColumn();

                $sheet->getStyle("A1:{$lastColumn}1")->applyFromArray([
                    'font' => [
                        'bold'  => true,
                        'color' => ['rgb' => 'F5F5F5'],
                    ],
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER,
                        'vertical'   => Alignment::VERTICAL_CENTER,
                    ],
                    'fill' => [
                        'fillType'   => Fill::FILL_SOLID,
                        'startColor' => ['rgb' => '993442'],
                    ],
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color'       => ['rgb' => '000000'],
                        ],
                    ],
                ]);

                $sheet->getRowDimension(1)->setRowHeight(25);
            },
        ];
    }
}
