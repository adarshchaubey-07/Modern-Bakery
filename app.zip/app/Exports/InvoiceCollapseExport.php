<?php

namespace App\Exports;

use App\Models\Agent_Transaction\InvoiceHeader;
use App\Models\Agent_Transaction\InvoiceDetail;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;

class InvoiceCollapseExport implements
    FromCollection,
    WithHeadings,
    ShouldAutoSize,
    WithEvents,
    WithStyles
{
    protected $from;
    protected $to;
    protected $groupIndexes = [];

    public function __construct($from = null, $to = null)
    {
        $this->from = $from;
        $this->to   = $to;
    }

    public function collection()
{
    $rows = [];
    $rowIndex = 2;

    $headers = InvoiceHeader::with([
        'company',
        'order',
        'delivery',
        'warehouse',
        'route',
        'customer',
        'salesman',
        'details.item',
        'details.uoms',
        'details.promotion',
    ])
        ->when($this->from, fn ($q) => $q->whereDate('invoice_date', '>=', $this->from))
        ->when($this->to, fn ($q) => $q->whereDate('invoice_date', '<=', $this->to))
        ->get();

    foreach ($headers as $header) {

        $details   = $header->details;
        $itemCount = $details->count(); 
        $headerRow = $rowIndex;

        $rows[] = [
            $header->invoice_code,
            $header->currency_name,
            $header->order->order_code ?? '',
            $header->delivery->delivery_code ?? '',
            trim(($header->warehouse->warehouse_code ?? '') . ' - ' . ($header->warehouse->warehouse_name ?? '')),
            trim(($header->route->route_code ?? '') . ' - ' . ($header->route->route_name ?? '')),
            trim(($header->customer->osa_code ?? '') . ' - ' . ($header->customer->name ?? '')),
            trim(($header->salesman->osa_code ?? '') . ' - ' . ($header->salesman->name ?? '')),
            optional($header->invoice_date)->format('Y-m-d'),
            $header->invoice_time,
            (float) $header->vat,
            (float) $header->net_total,
            (float) $header->gross_total,
            (float) $header->discount,
            (float) $header->total_amount,
            $header->status == 1 ? 'Active' : 'Inactive',
            $itemCount, 
            '', '', '', '', '', '', '',
        ];

        $rowIndex++;
        $detailRowIndexes = [];
        foreach ($details as $d) {
            $rows[] = [
                '', '', '', '', '', '', '', '',
                '', '', '', '', '', '', '', '',
                '',
                trim(($d->item->erp_code ?? '') . ' - ' . ($d->item->name ?? '')),
                $d->uoms->name ?? '',
                (float) $d->quantity,
                (float) $d->item_value,
                (float) $d->vat,
                (float) $d->net_total,
                (float) $d->item_total,
                $d->status == 1 ? 'Active' : 'Inactive',
            ];

            $detailRowIndexes[] = $rowIndex;
            $rowIndex++;
        }
        if (!empty($detailRowIndexes)) {
            $this->groupIndexes[] = [
                'start' => $headerRow + 1,
                'end'   => max($detailRowIndexes),
            ];
        }

        $rows[] = array_fill(0, count($rows[0]), '');
        $rowIndex++;
    }

    return new Collection($rows);
}

    public function headings(): array
    {
        return [
            'Invoice Code',
            'Currency Name',
            'Order Code',
            'Delivery Code',
            'Warehouse',
            'Route',
            'Customer',
            'Salesman',
            'Invoice Date',
            'Invoice Time',
            'VAT',
            'Net Total',
            'Gross Total',
            'Discount',
            'Total Amount',
            'Status',
            'Item Count',
            'Item',
            'UOM',
            'Quantity',
            'Item Value',
            'VAT (Detail)',
            'Net (Detail)',
            'Item Total',
            'Detail Status',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {

                $sheet = $event->sheet->getDelegate();
                $lastColumn = $sheet->getHighestColumn();
                $sheet->getStyle("A1:{$lastColumn}1")->applyFromArray([
                    'font' => [
                        'bold'  => true,
                        'color' => ['rgb' => 'FFFFFF'],
                    ],
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER,
                        'vertical'   => Alignment::VERTICAL_CENTER,
                    ],
                    'fill' => [
                        'fillType'   => Fill::FILL_SOLID,
                        'startColor' => ['rgb' => '993442'],
                    ],
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => Border::BORDER_THIN,
                        ],
                    ],
                ]);

                $sheet->getRowDimension(1)->setRowHeight(25);
                foreach ($this->groupIndexes as $group) {
                    for ($i = $group['start']; $i <= $group['end']; $i++) {
                        $sheet->getRowDimension($i)->setOutlineLevel(1);
                        $sheet->getRowDimension($i)->setVisible(false);
                    }
                }

                $sheet->setShowSummaryBelow(false);
            },
        ];
    }
}
