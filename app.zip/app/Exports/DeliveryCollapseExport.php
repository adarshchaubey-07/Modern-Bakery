<?php

namespace App\Exports;

use App\Models\Agent_Transaction\AgentDeliveryHeaders;
use App\Models\Agent_Transaction\AgentDeliveryDetails;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;

class DeliveryCollapseExport implements
    FromCollection,
    WithHeadings,
    ShouldAutoSize,
    WithEvents
{
    protected $groupIndexes = [];

   public function collection()
{
    $rows = [];
    $rowIndex = 2;

    $headers = AgentDeliveryHeaders::with([
        'warehouse',
        'route',
        'salesman',
        'customer',
        'details.item',
        'details.Uom',
    ])->get();

    foreach ($headers as $header) {

        $details   = $header->details;
        $itemCount = $details->count(); 
        $headerRow = $rowIndex;

        $rows[] = [
            $header->delivery_code ?? '',
            optional($header->created_at)->format('Y-m-d'),
            trim(($header->warehouse->warehouse_code ?? '') . '-' . ($header->warehouse->warehouse_name ?? '')),
            trim(($header->route->route_code ?? '') . '-' . ($header->route->route_name ?? '')),
            trim(($header->salesman->osa_code ?? '') . '-' . ($header->salesman->name ?? '')),
            trim(($header->customer->osa_code ?? '') . '-' . ($header->customer->name ?? '')),
            (float) ($header->vat ?? 0),
            (float) ($header->discount ?? 0),
            (float) ($header->net_amount ?? 0),
            (float) ($header->total ?? 0),
            $itemCount, 
            '', '', '', '', '', '', '',
        ];

        $rowIndex++;
        $detailRowIndexes = [];
        foreach ($details as $detail) {
            $rows[] = [
                '', '', '', '', '', '', '', '', '', '',
                '',
                trim(($detail->item->code ?? '') . '-' . ($detail->item->name ?? '')),
                $detail->Uom->name ?? '',
                (float) ($detail->item_price ?? 0),
                (float) ($detail->quantity ?? 0),
                (float) ($detail->vat ?? 0),
                (float) ($detail->discount ?? 0),
                (float) ($detail->net_total ?? 0),
                (float) ($detail->total ?? 0),
            ];

            $detailRowIndexes[] = $rowIndex;
            $rowIndex++;
        }
        if (!empty($detailRowIndexes)) {
            $this->groupIndexes[] = [
                'start' => $headerRow + 1,
                'end'   => max($detailRowIndexes),
            ];
        }
        $rows[] = array_fill(0, count($rows[0]), '');
        $rowIndex++;
    }

    return new Collection($rows);
}
    public function headings(): array
    {
        return [
            'Delivery Code',
            'Delivery Date',
            'Warehouse',
            'Route',
            'Salesman',
            'Customer',
            'VAT',
            'Discount',
            'Net Amount',
            'Total',
            'Item Count',
            'Item',
            'UOM',
            'Item Price',
            'Quantity',
            'Item VAT',
            'Item Discount',
            'Item Net',
            'Item Total',
        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {

                $sheet = $event->sheet->getDelegate();
                $lastColumn = $sheet->getHighestColumn();
                $sheet->getStyle("A1:{$lastColumn}1")->applyFromArray([
                    'font' => [
                        'bold'  => true,
                        'color' => ['rgb' => 'F5F5F5'],
                    ],
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER,
                        'vertical'   => Alignment::VERTICAL_CENTER,
                    ],
                    'fill' => [
                        'fillType'   => Fill::FILL_SOLID,
                        'startColor' => ['rgb' => '993442'],
                    ],
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color'       => ['rgb' => '000000'],
                        ],
                    ],
                ]);

                $sheet->getRowDimension(1)->setRowHeight(25);
                foreach ($this->groupIndexes as $group) {
                    for ($i = $group['start']; $i <= $group['end']; $i++) {
                        $sheet->getRowDimension($i)->setOutlineLevel(1);
                        $sheet->getRowDimension($i)->setVisible(false);
                    }
                }

                $sheet->setShowSummaryBelow(false);
            },
        ];
    }
}
